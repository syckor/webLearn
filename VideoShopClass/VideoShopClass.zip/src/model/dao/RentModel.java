package model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;


public class RentModel {
	
	
	Connection con;
	
	public RentModel() throws Exception{
		// 1. 드라이버로딩
				
	}
	
	
}
