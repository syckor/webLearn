package model.dao;

import model.VideoDao;
import model.vo.Video;

public class VideoModel implements VideoDao{
	
	public VideoModel() throws Exception{
		

		// 1. 드라이버로딩
		
		
	}
	
	
	public void insertVideo(Video vo, int count) throws Exception{
		// 2. Connection 연결객체 얻어오기
		// 3. sql 문장 만들기
		// 4. sql 전송객체 (PreparedStatement)		
		// 5. sql 전송
		// 6. 닫기
	}
	

}
