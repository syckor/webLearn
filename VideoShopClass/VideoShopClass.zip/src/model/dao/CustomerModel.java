package model.dao;

import model.CustomerDao;
import model.vo.Customer;

public class CustomerModel implements CustomerDao{

	
	
	public CustomerModel() throws Exception{
	 	// 1. 드라이버로딩
		
		
	}
	
	public void insertCustomer(Customer vo) throws Exception{
		// 2. Connection 연결객체 얻어오기
		// 3. sql 문장 만들기
		// 4. sql 전송객체 (PreparedStatement)		
		// 5. sql 전송
		// 6. 닫기 

	}
	
	public Customer selectByTel(String tel) throws Exception{
		Customer dao = new Customer();
		
		
		return dao;
		
	}
	
	public int updateCustomer(Customer vo) throws Exception{
		
		int result = 0;
		
		
		return result;
	}
}
